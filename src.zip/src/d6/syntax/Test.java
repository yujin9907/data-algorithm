package d6.syntax;


// 인터페이스 설명

public interface Test {
    public int f1(int i);
    public int f2(int i);
}

