package d6.syntax;

public class Test1 implements Test {

    @Override
    public int f1(int i) {
        return 0;
    }

    @Override
    public int f2(int i) {
        return 0;
    }
}
