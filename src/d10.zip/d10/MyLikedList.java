package d10;

// double linked list
public class MyLikedList<T> {
    class Node {
        T data;
        Node prev;
        Node next;

        Node(T d) {
            data=d;
            prev=null;
            next=null;
        }

        public String toString() {
            return ""+data.toString();
        }
    }

    Node head, tail;
    int size;

    public MyLikedList() {
        head = null;
        tail = null;
    }

    public void add(T value) {
        addFirst(value);
    }
    public void addFirst(T value) {
        Node newNode = new Node(value);
        if (isEmpty()) {
            head = newNode;
            tail = head;
        } else {
            newNode = head;
            head.prev = newNode;
        }
    }

    private boolean isEmpty() {
        return head==null;
    }
}
