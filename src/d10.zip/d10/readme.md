* 우리 수업의 목적

1. 리커전
2. 링크드리스트로 활용되는 무언가 (week10의 MySchedule - linkedList 활용1)


* 참고
1. 다음 시간에 remove 와 관련된 Index 수정할 거라는데 잘 못 들었음